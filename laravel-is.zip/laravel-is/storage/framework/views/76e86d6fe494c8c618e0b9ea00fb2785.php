<html>
<head>
<style>
footer {
  text-align: center;
  padding: 3px;
  background-color: DarkSalmon;
  color: white;
}
</style>
</head>
<body>

<footer>
  <p>Author: Hege Refsnes<br>
  <a href="mailto:hege@example.com">hege@example.com</a></p>
</footer>

</body>
</html><?php /**PATH C:\laravelprojects\laravel-is\resources\views/partials/footer.blade.php ENDPATH**/ ?>