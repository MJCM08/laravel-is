<ul class="navbar-nav">
<li class="nav-item px-6 py-4 font-medium text-gray-900">
<a class="nav-link active" aria-current="page" href={{'/'}}>Home</a>
</li>
<li class="nav-item px-6 py-4 font-medium text-gray-900">
<a class="nav-link" href={{'/editprofile'}}>Edit Profile</a>
</li>

<li class="nav-item px-6 py-4 font-medium text-gray-900">
<a class="nav-link" href={{"/logout"}}>Logout</a>
</li>

</ul>